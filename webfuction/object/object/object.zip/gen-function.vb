﻿Imports ICSharpCode.SharpZipLib.Zip

Module PublicData

    Public makefileplayer As Boolean = True ' Abilita la generazione dei file con la lista dei giocatori trovati'
    Public webplayers As New Dictionary(Of String, Dictionary(Of String, Generic.List(Of String)))
    Public webmatchs As New Dictionary(Of String, Integer)
    Public dirs As String = ""
    'COGNOME NOME/NOME LENGHT/LIST NOME ASSOCIATI'
    Public wplayer As New Dictionary(Of String, SortedDictionary(Of Integer, Generic.List(Of WebData.WebPlayer)))

End Module

Public Class WebData

    Public Shared Sub MakeDirectory(ServerPath As String, Year As Integer)

        Dim dirt As String = ServerPath & "\web\" & CStr(Year) & "\temp"
        Dim dird As String = ServerPath & "\web\" & CStr(Year) & "\data"
        Dim dirdpf As String = ServerPath & "\web\" & CStr(Year) & "\data\pforma"

        If IO.Directory.Exists(dirt) = False Then IO.Directory.CreateDirectory(dirt)
        If IO.Directory.Exists(dird) = False Then IO.Directory.CreateDirectory(dird)
        If IO.Directory.Exists(dirdpf) = False Then IO.Directory.CreateDirectory(dirdpf)

    End Sub

    Public Shared Function ExtractIntegerData(Value As String, RegEx As String, DefaultValue As Integer) As Integer

        Try
            Dim s As String = System.Text.RegularExpressions.Regex.Match(Value, RegEx).Value
            If s <> "" Then DefaultValue = CInt(s)
        Catch ex As Exception

        End Try

        Return DefaultValue

    End Function

    Public Shared Function NormalizeText(ByVal txt As String) As String

        If txt.Contains("AMBROSIO") Then
            txt = txt
        End If

        txt = txt.Replace("-", " ")
        txt = txt.Replace("'", "’")
        txt = txt.Replace("&#39;", "’")
        txt = txt.Replace("Ò", "O’")
        txt = txt.Replace("&#210;", "O’")
        txt = txt.Replace("É", "E’")
        txt = txt.Replace("&#201;", "E’")
        txt = txt.Replace("&#193;", "A")
        txt = txt.Replace("Ã²", "O’")
        txt = txt.Replace("Ã¨", "A")
        txt = txt.Replace("Ã", "A")
        txt = txt.Replace("Ó", "O")
        txt = txt.Replace("&#211;", "O")
        txt = txt.Replace("Í", "I")
        txt = txt.Replace("&#205;", "I")
        txt = txt.Replace("È", "E")
        txt = txt.Replace("&#200;", "E")
        txt = txt.Replace("Á", "A")
        txt = txt.Replace("À", "A’")
        txt = txt.Replace("&#192;", "A’")
        txt = txt.Replace("Ú", "U")
        txt = txt.Replace("&#218;", "U")
        txt = txt.Replace("Ñ", "N")
        txt = txt.Replace("&#209;", "N")
        txt = txt.Replace("&#39;", "'")
        txt = txt.Replace("â", "A’")
        txt = txt.Replace("-", " ")

        Dim regex As New System.Text.RegularExpressions.Regex("[0-9a-zA-Z\'\s\.\-\’]{0,}")
        Dim newtxt As String = ""

        For Each match As System.Text.RegularExpressions.Match In regex.Matches(txt)
            If match.Value.Trim <> "" Then newtxt = newtxt & match.Value
        Next

        Return newtxt

    End Function

    Public Shared Function ResolveName(Role As String, Name As String, Team As String) As String
        Return ResolveName(Role, Name, Team, Nothing)
    End Function

    Public Shared Function ResolveName(Role As String, Name As String, Team As String, wp As Dictionary(Of String, PlayerMatch)) As String

        'Normalizo la stringa di testo contenente il nome del giocatore'
        Name = Name.ToUpper
        Name = Name.Trim
        If Name.Contains("RONALDO") Then
            Name = Name
        End If
        Name = NormalizeText(Name)
        Name = Name.Replace("’", "")

        'Cerco il nome del giocatore tra quella delle quotazioni'
        Dim pm As WebData.PlayerMatch = WebData.CheckName(Role, Name, Team)
        If wp IsNot Nothing Then If wp.ContainsKey(Name) = False Then wp.Add(Name, pm)

        Return pm.GetName

    End Function

    Public Shared Function CheckName(ByVal Name As String) As PlayerMatch
        Return CheckName("", Name, "")
    End Function

    Public Shared Function CheckName(ByVal Name As String, Team As String) As PlayerMatch
        Return CheckName("", Name, Team)
    End Function

    Public Shared Function CheckName(Role As String, ByVal Name As String, Team As String) As PlayerMatch

        Name = Name.Trim

        Dim s() As String = Name.Split(CChar(" "))
        Dim check As New PlayerMatch(Role, Name, Team)

        If Name.Contains("RODRIGUEZ R.") Then
            Name = Name
        End If

        If s.Length = 3 Then
            'Nel caso in cui la stringa e' formata da 3 sotto stringhe
            'significa che siamo in presenza di un cognome composto
            'e quindi ricostrisco il cognome completo unendo le due sotto stringhe
            'ex. DE LAURENTIS MIRCO'
            'S(0)=DE  -  S(1)=LAURENTIS  -  S(2)=MIRCO
            'S1=s(0)+s(1) -> DE LAURENTIS
            If wplayer.ContainsKey(s(0) & " " & s(1)) Then
                check = CheckName(s(0) & " " & s(1), s(2), Role, Team)
            End If
            If check.Matched = False AndAlso wplayer.ContainsKey(s(1) & " " & s(2)) Then
                check = CheckName(s(1) & " " & s(2), s(0), Role, Team)
            End If
            If check.Matched = False AndAlso wplayer.ContainsKey(s(0)) Then
                check = CheckName(s(0), s(1), Role, Team)
                If check.Matched = False Then
                    check = CheckName(s(0), s(2), Role, Team)
                End If
            End If
            If check.Matched = False AndAlso wplayer.ContainsKey(s(1)) Then
                check = CheckName(s(1), s(0), Role, Team)
                If check.Matched = False Then
                    check = CheckName(s(1), s(2), Role, Team)
                End If
            End If
            If check.Matched = False AndAlso wplayer.ContainsKey(s(2)) Then
                check = CheckName(s(2), s(0), Role, Team)
                If check.Matched = False Then
                    check = CheckName(s(2), s(1), Role, Team)
                End If
            End If
        ElseIf s.Length = 2 Then
            'Cerco assumendo che il primo campo sia il cognome Ex. MALDINI PAOLO'
            If wplayer.ContainsKey(s(0)) Then
                check = CheckName(s(0), s(1), Role, Team)
            ElseIf wplayer.ContainsKey(s(0)) Then 'rieseguo la richerca eliminando gli apostrofi'
                check = CheckName(s(0), s(1), Role, Team)
            End If
            'Cerco assumendo che il primo campo sia il nome Ex. PAOLO MALDINI'
            If check.Matched = False Then
                If wplayer.ContainsKey(s(1)) Then
                    check = CheckName(s(1), s(0), Role, Team)
                ElseIf wplayer.ContainsKey(s(1)) Then 'rieseguo la richerca eliminando gli apostrofi'
                    check = CheckName(s(1), s(0), Role, Team)
                End If
            End If
            'Cerco assumendo che i due valori facciano riferimento ad un cognome composto Es. DE FRANCESCO'
            If check.Matched = False Then
                If wplayer.ContainsKey(s(0) & " " & s(1)) Then
                    check = CheckName(s(0) & " " & s(1), "", Role, Team)
                End If
            End If
        Else
            'Cerco assumendo che il valore faccia riferimento al solo cognome Es. FRANCESCHINI'
            If wplayer.ContainsKey(s(0)) Then
                check = CheckName(s(0), "", Role, Team)
            ElseIf wplayer.ContainsKey(s(0)) Then 'rieseguo la richerca eliminando gli apostrofi'
                check = CheckName(s(0), "", Role, Team)
            End If
        End If

        Return check

    End Function

    Private Shared Function CheckName(S1 As String, S2 As String, Ruolo As String, Squadra As String) As PlayerMatch

        Dim text As String = S1 & " " & S2
        Dim check As New PlayerMatch(text.Trim)

        Try

            Dim key(wplayer(S1).Keys.Count - 1) As Integer
            Dim c As Integer = 0

            text = text.Trim

            If S1.Contains("GERSON") OrElse S2.Contains("GERSON") Then
                S1 = S1
            End If

            For Each l As Integer In wplayer(S1).Keys
                key(c) = l
                c = c + 1
            Next

            Array.Sort(key)
            Array.Reverse(key)

            For Each l As Integer In key

                For k As Integer = 0 To wplayer(S1)(l).Count - 1

                    Dim sname As String = wplayer(S1)(l)(k).Name.Replace(".", "")

                    If S2 = "" Then sname = S1

                    If text.StartsWith(sname) Then
                        If Squadra = "" OrElse Squadra = wplayer(S1)(l)(k).Team Then
                            If Ruolo = "" OrElse Ruolo = wplayer(S1)(l)(k).Role Then
                                check.MatchedPlayer.Role = wplayer(S1)(l)(k).Role
                                check.MatchedPlayer.Name = wplayer(S1)(l)(k).Name
                                check.MatchedPlayer.Team = wplayer(S1)(l)(k).Team
                                Exit For
                            End If
                        End If
                    End If
                Next

                If check.Matched Then Exit For

            Next
        Catch ex As Exception
            Call WriteError(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message)
        End Try

        Return check

    End Function

    Public Function GetDicNatCodeList(fname As String) As Dictionary(Of String, String)

        Dim dicnatcode As New Dictionary(Of String, String)

        If IO.File.Exists(fname) Then
            Dim line() As String = IO.File.ReadAllLines(fname)
            For i As Integer = 0 To line.Length - 1
                Dim s() As String = line(i).Split(CChar(","))
                If s.Length = 2 Then
                    If dicnatcode.ContainsKey(s(0)) = False Then dicnatcode.Add(s(0), s(1))
                End If
            Next
        End If

        Return dicnatcode

    End Function

    Public Shared Sub LoadWebPlayers(fname As String)

        If webplayers.Count = 0 Then

            If IO.File.Exists(fname) Then

                Dim lines() As String = IO.File.ReadAllLines(fname, System.Text.Encoding.GetEncoding("ISO-8859-1"))

                For i As Integer = 0 To lines.Length - 1

                    Dim s() As String = lines(i).Split(CChar("|"))

                    If s.Length = 5 Then

                        Dim role As String = s(0)
                        Dim name As String = s(1).Replace("’", "")
                        Dim team As String = s(2)

                        If webplayers.ContainsKey(team) = False Then webplayers.Add(team, New Dictionary(Of String, Generic.List(Of String)))
                        If webplayers(team).ContainsKey(role) = False Then webplayers(team).Add(role, New Generic.List(Of String))

                        webplayers(team)(role).Add(name)

                        If name.Contains("MERET") Then
                            name = name
                        End If

                        Dim sn() As String = name.Split(CChar(" "))
                        Dim key As String = ""
                        Dim subkey As String = ""

                        If sn.Length > 2 Then
                            key = sn(0) & " " & sn(1)
                            subkey = sn(2)
                        ElseIf sn.Length > 1 Then
                            key = sn(0)
                            subkey = sn(1)
                        Else
                            key = sn(0)
                        End If

                        Dim l As Integer = subkey.Length

                        If wplayer.ContainsKey(key) = False Then wplayer.Add(key, New SortedDictionary(Of Integer, Generic.List(Of WebPlayer)))
                        If wplayer(key).ContainsKey(l) = False Then wplayer(key).Add(l, New Generic.List(Of WebPlayer))

                        wplayer(key)(l).Add(New WebPlayer(role, name, team))

                    End If
                Next
            End If

        End If

    End Sub

    Public Shared Sub LoadWebMatchs(fname As String)

        If webmatchs.Count = 0 Then

            If IO.File.Exists(fname) Then

                Dim lines() As String = IO.File.ReadAllLines(fname)

                For i As Integer = 0 To lines.Length - 1
                    Dim s() As String = lines(i).Split(CChar("|"))
                    If s.Length = 5 Then

                        Dim gg As Integer = CInt(s(0)) 'giornata'
                        Dim t1 As String = s(2) 'squadra in casa'
                        Dim t2 As String = s(3) 'squadra fuori casa'
                        Dim key As String = t1 & "-" & t2

                        If webmatchs.ContainsKey(key) = False Then webmatchs.Add(key, gg)

                    End If
                Next
            End If

        End If

    End Sub

    Public Shared Function CheckTeamName(ByVal Squadra As String) As String
        Squadra = Squadra.ToUpper.Replace("CHIEVOVERONA", "CHIEVO").Trim
        Squadra = Squadra.ToUpper.Replace("CHIEVO-VERONA", "CHIEVO").Trim
        Squadra = Squadra.ToUpper.Replace("CHIEVO VERONA", "CHIEVO").Trim
        Squadra = Squadra.ToUpper.Replace("HELLASVERONA", "VERONA").Trim
        Squadra = Squadra.ToUpper.Replace("HELLAS-VERONA", "VERONA").Trim
        Squadra = Squadra.ToUpper.Replace("HELLAS VERONA", "VERONA").Trim
        If Squadra.ToUpper = "JUVE" Then Squadra = "JUVENTUS"
        Return Squadra
    End Function

    Public Function GetNatCode(natcode As String) As String
        Select Case natcode
            Case "REP" : natcode = "CZE"
            Case "ING" : natcode = "GBR"
            Case "ENG" : natcode = "GBR"
            Case "CHI" : natcode = "CHL"
            Case "GRE" : natcode = "GRC"
            Case "GUI" : natcode = "GIN"
            Case "CRO" : natcode = "HRV"
            Case "SUI" : natcode = "CHE"
            Case "DAN" : natcode = "DNK"
            Case "GAM" : natcode = "GMB"
            Case "POR" : natcode = "PRT"
            Case "PAR" : natcode = "PRY"
            Case "NED" : natcode = "NLD"
            Case "GER" : natcode = "DEU"
            Case "CRC" : natcode = "CRI"
            Case "BUL" : natcode = "BGR"
            Case "URU" : natcode = "URY"
            Case "ALG" : natcode = "DZA"
            Case "SLO" : natcode = "SVK"
            Case "CIL" : natcode = "CHL"
            Case "MOL" : natcode = "MDA"
            Case "SVE" : natcode = "SWE"
            Case "SER" : natcode = "SVK"
            Case "SPA" : natcode = "ESP"
            Case "ROM" : natcode = "ROU"
            Case "OLA" : natcode = "NLD"
            Case "COS" : natcode = "CIV"
            Case "SVI" : natcode = "SWZ"
            Case "BOS" : natcode = "BIH"
            Case "GIA" : natcode = "JAM"
            Case "SNV" : natcode = "SVN"
            Case "UNG" : natcode = "HUN"
            Case "LIB" : natcode = "LBY"
            Case "LIT" : natcode = "LTU"
            Case "NIG" : natcode = "NER"
            Case "IRA" : natcode = "IRN"
            Case "MON" : natcode = "MNE"
            Case "EGI" : natcode = "EGY"
            Case "ANG" : natcode = "AGO"
            Case "MES" : natcode = "MEX"
            Case "CAM" : natcode = "CMR"
            Case "MAL" : natcode = "MLI"
            Case "COR" : natcode = "KOR"
            Case "GUA" : natcode = "GLP"
            Case "DEN" : natcode = "DNK"
            Case "KVX" : natcode = "RKS"
        End Select
        Return natcode
    End Function

   Public Shared Sub WriteLog(dirs As String,ByVal Form As String, ByVal SubName As String, ByVal Text As String)
        Try
            If IO.Directory.Exists(dirs) Then IO.File.AppendAllText(dirs & "\debug.log", Date.Now.ToString("yyyy/MM/dd HH:mm:ss") & "|" & Form & "|" & SubName & "|" & Text & System.Environment.NewLine)
        Catch ex As Exception

        End Try
    End Sub
	
    Public Shared Sub WriteError(ByVal Form As String, ByVal SubName As String, ByVal ErrMsg As String)
        Try
            If IO.Directory.Exists(dirs) Then IO.File.AppendAllText(dirs & "\error.log", Date.Now.ToString("yyyy/MM/dd HH:mm:ss") & "|" & Form & "|" & SubName & "|" & ErrMsg & System.Environment.NewLine)
        Catch ex As Exception

        End Try
    End Sub

    Public Shared Sub WriteDataPlayerMatch(wp As Dictionary(Of String, PlayerMatch), filed As String)
        Try

            Dim strdata As New System.Text.StringBuilder
            Dim notfound As New Generic.List(Of WebPlayer)

            strdata.AppendLine("***List players***")

            For Each pkey As String In wp.Keys
                strdata.AppendLine(wp(pkey).SourcePlayer.Role & "|" & wp(pkey).SourcePlayer.Name & "|" & wp(pkey).SourcePlayer.Team & "|" & wp(pkey).MatchedPlayer.Role & "|" & wp(pkey).MatchedPlayer.Name & "|" & wp(pkey).MatchedPlayer.Team)
                If wp(pkey).Matched = False Then notfound.Add(wp(pkey).SourcePlayer)
            Next
            strdata.AppendLine("")
            strdata.AppendLine("***List players not found***")
            For i As Integer = 0 To notfound.Count - 1
                strdata.AppendLine(notfound(i).Role & "|" & notfound(i).Name & "|" & notfound(i).Team)
            Next
            strdata.AppendLine("")
            strdata.AppendLine("***Report data***")
            strdata.AppendLine("Number of players = " & wp.Count)
            strdata.AppendLine("Number of players not found = " & notfound.Count)
            If wp.Count > 0 Then
                strdata.AppendLine("Percentage players not found = " & CInt((notfound.Count * 1000) / wp.Count) / 10 & "%")
            Else
                strdata.AppendLine("Percentage players not found = 0%")
            End If

            IO.File.WriteAllText(filed, strdata.ToString, System.Text.Encoding.UTF8)

        Catch ex As Exception
            Call WriteError(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message)
        End Try
    End Sub

    Public Class PlayerMatch

        Dim _source As New WebPlayer
        Dim _new As New WebPlayer

        Sub New(Name As String)
            _source.Name = Name
        End Sub

        Sub New(Role As String, Name As String)
            _source.Role = Role
            _source.Name = Name
        End Sub

        Sub New(Role As String, Name As String, Team As String)
            _source.Role = Role
            _source.Name = Name
            _source.Team = Team
        End Sub

        Public Property SourcePlayer As WebPlayer
            Get
                Return _source
            End Get
            Set(value As WebPlayer)
                _source = value
            End Set
        End Property

        Public Property MatchedPlayer As WebPlayer
            Get
                Return _new
            End Get
            Set(value As WebPlayer)
                _new = value
            End Set
        End Property

        Public ReadOnly Property Matched As Boolean
            Get
                If _new.Name = "" Then
                    Return False
                Else
                    Return True
                End If
            End Get
        End Property

        Public Function GetName() As String
            If _new.Name <> "" Then
                Return _new.Name
            Else
                Return _source.Name
            End If
        End Function

    End Class
End Class
