﻿Partial Class WebData
    Public Class MatchData

        Private thrmatch As New Generic.List(Of Threading.Thread)
        Private diclinkday As New SortedDictionary(Of Integer, String)
        Private diclinkdaymatch As New SortedDictionary(Of Integer, Dictionary(Of Integer, String))
        Private dirt As String = ""
        Private dird As String = ""
        Private strdata As New SortedDictionary(Of Integer, System.Text.StringBuilder)
        Private year As Integer = -1

        Sub New(YearLega As Integer)
            year = YearLega
        End Sub

        Function GetCalendarMatchs(ServerPath As String, ReturnData As Boolean) As String

            Dim filed As String = ""
            Dim strdataall As New System.Text.StringBuilder

            dirs = ServerPath
            dirt = ServerPath & "\web\" & CStr(year) & "\temp"
            dird = ServerPath & "\web\" & CStr(year) & "\data"
            filed = dird & "\matchs-data.txt"

            Call MakeDirectory(ServerPath, Year)
            Call LoadWebPlayers(ServerPath & "\web\" & CStr(year) & "\data\players-quote.txt")

            Try

                Dim flgg As String = dirt & "\match-data-list-gg.txt"
                Dim html As String = GetPage("http://www.legaseriea.it/it/serie-a-tim/calendario-e-risultati/" & year & "-" & CStr(year - 1999) & "/UNICO/UNI/1", "POST", "")

                If html <> "" Then

                    IO.File.WriteAllText(flgg, html)

                    Dim line() As String = IO.File.ReadAllLines(flgg)

                    For i As Integer = 0 To line.Length - 1
                        If line(i).Contains("UNICO/UNI") Then
                            Dim day As Integer = CInt(System.Text.RegularExpressions.Regex.Match(line(i), "(?<=/UNI/.*)\d+").Value)
                            Dim daylink As String = "http://www.legaseriea.it" & System.Text.RegularExpressions.Regex.Match(line(i), "(?<=href\="").*(?="")").Value
                            If diclinkday.ContainsKey(day) = False Then
                                diclinkday.Add(day, daylink)
                            End If
                        End If
                    Next

                    'Creo la lista di thread da eseguire'
                    thrmatch.Clear()
                    For Each d As Integer In diclinkday.Keys
                        Dim t As New Threading.Thread(AddressOf GetMatchsDay)
                        t.Name = CStr(d)
                        thrmatch.Add(t)
                        'If d > 1 Then Exit For
                    Next

                    'Lancio i vari Thread'
                    For i As Integer = 0 To thrmatch.Count - 1
                        thrmatch(i).Priority = Threading.ThreadPriority.Normal
                        thrmatch(i).Start()
                        thrmatch(i).Join()
                        System.Threading.Thread.Sleep(100)
                    Next

                    For Each key As Integer In strdata.Keys
                        strdataall.Append(strdata(key).ToString)
                    Next

                    IO.File.WriteAllText(filed, strdataall.ToString)

                End If

            Catch ex As Exception
                Call WriteError(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message)
                Return ""
            End Try

            Call GetMatchsScoresheet()

            If ReturnData Then
                strdataall.Append("</br><span style=color:red;font-size:bold;'>Detail match data:</span></br>")
                For Each key As Integer In strdata.Keys
                    strdataall.Append(strdata(key).ToString)
                Next
                Return "</br><span style=color:red;font-size:bold;'>Match data (" & year & "):</span></br>" & strdataall.ToString.Replace(System.Environment.NewLine, "</br>") & "</br>"
            Else
                Return ("</br><span style=color:red;font-size:bold;'>Match data (" & year & "):</span><span style=color:blue;font-size:bold;'>Compleated!!</span></br><span style=color:red;font-size:bold;'>Detail match data:</span><span style=color:blue;font-size:bold;'>Compleated!!</span></br>")
            End If

        End Function

        Private Sub GetMatchsDay()
            Try
                'Determino la giornata di riferimento'
                Dim d As Integer = CInt(Threading.Thread.CurrentThread.Name)

                If diclinkday.ContainsKey(d) Then

                    Dim datamatch As New Dictionary(Of String, String)
                    Dim filet As String = dirt & "\match-day-" & CStr(d) & ".txt"
                    Dim filed As String = dirt & "\match-day-" & CStr(d) & ".txt"
                    Dim html As String = GetPage(diclinkday(d), "POST", "")

                    If html <> "" Then

                        Dim day As String = ""
                        Dim dt As New Date(Date.Now.Year, Date.Now.Month, Date.Now.Day, 0, 0, 0)
                        Dim squadraa As String = ""
                        Dim squadrab As String = ""
                        Dim line() As String
                        Dim matchid As Integer = 0
                        Dim matchplayed As Boolean = False

                        strdata.Add(d, New System.Text.StringBuilder)

                        IO.File.WriteAllText(filet, html)
                        line = IO.File.ReadAllLines(filet)

                        For i As Integer = 0 To line.Length - 1
                            If line(i) <> "" Then
                                If line(i).Contains("Stadio:") Then
                                    matchid += 1
                                    matchplayed = False
                                End If
                                If line(i).Contains("class=""datipartita""") Then
                                    day = System.Text.RegularExpressions.Regex.Match(line(i + 2), "\d+/\d+/\d+\s+\d+:\d+").Value.Replace(" ", "/").Replace(":", "/")
                                    Dim days() As String = day.Split(CChar("/"))
                                    If days.Length = 5 Then
                                        dt = New Date(CInt(days(2)), CInt(days(1)), CInt(days(0)), CInt(days(3)), CInt(days(4)), 0)
                                    End If
                                End If
                                If line(i).Contains("col-xs-6 risultatosx") Then
                                    squadraa = System.Text.RegularExpressions.Regex.Match(line(i + 1), "(?<=title="").*(?="")").Value.ToUpper
                                    squadraa = CheckTeamName(squadraa)
                                End If
                                If line(i).Contains("col-xs-6 risultatodx") Then
                                    squadrab = System.Text.RegularExpressions.Regex.Match(line(i + 2), "(?<=title="").*(?="")").Value.ToUpper
                                    squadrab = CheckTeamName(squadrab)
                                    If datamatch.ContainsKey(d & "-" & squadraa & "-" & squadrab) = False Then datamatch.Add(d & "-" & squadraa & "-" & squadrab, d & "|" & matchid & "|" & squadraa & "|" & squadrab & "|" & dt.ToString("yyyy/MM/dd HH:mm:ss"))
                                    If System.Text.RegularExpressions.Regex.Match(line(i + 1), "\<span\>\d+\<\/span\>").Value.Length > 0 Then
                                        matchplayed = True
                                    Else
                                        matchplayed = False
                                    End If
                                End If
                                If matchplayed AndAlso line(i).Contains("serie-a/match-report/") Then
                                    Dim linktab As String = "http://www.legaseriea.it" & System.Text.RegularExpressions.Regex.Match(line(i), "(?<=\"").*(?=\"")").Value
                                    If diclinkdaymatch.ContainsKey(d) = False Then diclinkdaymatch.Add(d, New Dictionary(Of Integer, String))
                                    If diclinkdaymatch(d).ContainsKey(matchid) = False Then diclinkdaymatch(d).Add(matchid, linktab)
                                End If
                            End If
                        Next
                    End If

                    For Each key As String In datamatch.Keys
                        strdata(d).AppendLine(datamatch(key))
                    Next

                End If

            Catch ex As Exception
                Call WriteError(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message)
            End Try
        End Sub

        Private Sub GetMatchsScoresheet()

            Try
                Dim strdataall As New System.Text.StringBuilder
                Dim filedetd As String = dird & "\matchs-detail-data.txt"

                strdata.Clear()

                'Carico i dati dell'ultima lettura'
                Call LoadMatchsScoresheet(filedetd)

                If diclinkdaymatch.Count > 0 Then

                    Dim lastday As Integer = diclinkdaymatch.Keys(diclinkdaymatch.Keys.Count - 1)

                    'Creo la lista di thread da eseguire'
                    thrmatch.Clear()
                    For Each d As Integer In diclinkdaymatch.Keys
                        'Ricarico i dati se nella precedente acquisizione non e' sono stati prelevati i tabellini della giornata
                        'oppure se la giornata non e' piu' vecchia di di due giornate oppure se non tutti i match della giornata
                        'stati disputati'
                        If strdata.ContainsKey(d) = False OrElse d > lastday - 2 OrElse diclinkdaymatch(d).Count < 10 Then
                            If strdata.ContainsKey(d) Then strdata.Remove(d)
                            Dim t As New Threading.Thread(AddressOf GetDayMatchsScoresheet)
                            t.Name = CStr(d)
                            thrmatch.Add(t)
                        End If
                    Next

                    'Lancio i vari Thread'
                    For i As Integer = 0 To thrmatch.Count - 1
                        thrmatch(i).Priority = Threading.ThreadPriority.Normal
                        thrmatch(i).Start()
                        thrmatch(i).Join()
                        System.Threading.Thread.Sleep(100)
                    Next

                    For Each key As Integer In strdata.Keys
                        strdataall.Append(strdata(key).ToString)
                    Next

                    IO.File.WriteAllText(filedetd, strdataall.ToString)

                End If
            Catch ex As Exception
                Call WriteError(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message)
            End Try
        End Sub

        Private Sub LoadMatchsScoresheet(fname As String)
            Try
                If IO.File.Exists(fname) Then
                    Dim lines() As String = IO.File.ReadAllLines(fname)
                    For i As Integer = 0 To lines.Length - 1
                        Dim s() As String = lines(i).Split(CChar("|"))
                        If s.Length = 6 Then
                            Dim d As Integer = CInt(s(0))
                            If strdata.ContainsKey(d) = False Then strdata.Add(d, New System.Text.StringBuilder)
                            strdata(d).AppendLine(lines(i))
                        End If
                    Next
                End If
            Catch ex As Exception
                Call WriteError(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message)
            End Try
        End Sub

        Private Sub GetDayMatchsScoresheet()
            Try
                'Determino la giornata di riferimento'
                Dim d As Integer = CInt(Threading.Thread.CurrentThread.Name)

                strdata.Add(d, New System.Text.StringBuilder)

                For Each m As Integer In diclinkdaymatch(d).Keys
                    Call GetDayMatchScoresheet(d, m, diclinkdaymatch(d)(m))
                Next

            Catch ex As Exception
                Call WriteError(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message)
            End Try
        End Sub

        Private Sub GetDayMatchScoresheet(day As Integer, MatchId As Integer, Link As String)

            Dim filet As String = dirt & "\match-day-" & day & "-matchid-" & MatchId & ".txt"
            Dim str As New System.Text.StringBuilder

            Try

                Dim html As String = GetPage(Link, "POST", "")

                If html <> "" Then

                    IO.File.WriteAllText(filet, html)

                    Dim line() As String = IO.File.ReadAllLines(filet)
                    Dim name As String = ""
                    Dim team As String = ""
                    Dim sost As Boolean = False
                    Dim sube As Boolean = False
                    Dim min As Integer = 90
                    Dim tit As Boolean = True
                    Dim st As Integer = 0

                    System.Threading.Thread.Sleep(1000)

                    For z As Integer = 0 To line.Count - 1

                        If line(z) <> "" Then
                            'Determino il nome della squadra'
                            If System.Text.RegularExpressions.Regex.Match(line(z).Trim, "<h3>(Formazione|Panchina)").Success Then
                                team = System.Text.RegularExpressions.Regex.Match(line(z).Trim, "(?<=(Formazione|Panchina)\s).*(?=\<\/h3\>)").Value.Trim
                                team = CheckTeamName(team)
                                If System.Text.RegularExpressions.Regex.Match(line(z).Trim, "Panchina").Success Then
                                    tit = False
                                Else
                                    tit = True
                                End If
                            End If

                            'Determino il nome del giocatore'
                            If line(z).Contains("<!-- nome -->") Then
                                sost = False : sube = False
                                name = System.Text.RegularExpressions.Regex.Match(line(z).Trim, "(?<=td\>).*(?=\<\/)").Value.ToUpper
                                If name.Contains("PELLEGRINI") Then
                                    name = name
                                End If
                                name = NormalizeText(name)
                                name = ResolveName("", name, team)
                                If name.Contains("PELLEGRINI") Then
                                    name = name
                                End If
                                If tit Then min = 90 Else min = 0
                            End If

                            'Determino se il giocatore e' entrato o uscito'
                            If System.Text.RegularExpressions.Regex.Match(line(z).Trim, "alt\=\""(Entra|Esce)\""\stitle\=\""(Entra|Esce)\""").Success Then
                                Dim smin As String = System.Text.RegularExpressions.Regex.Match(line(z + 2).Trim, "\d+").Value
                                If line(z).Contains("alt=""Entra"" title=""Entra""") Then sube = True Else sost = True
                                If smin <> "" Then min = CInt(smin)
                            End If

                            'Scrivo i dati del giocatore'
                            If line(z).Contains("<!-- minuto sostituzioni -->") Then
                                If min <> 90 AndAlso min <> 0 Then
                                    If sube Then min = 90 - min
                                End If
                                If min < 0 Then min = 0
                                If min > 90 Then min = 90
                                strdata(day).AppendLine(day & "|" & MatchId & "|" & team & "|" & name & "|" & CStr(min) & "|" & CStr(Math.Abs(CInt(tit))) & "|" & CStr(Math.Abs(CInt(sost))) & "|" & CStr(Math.Abs(CInt(sube))))
                            End If
                        End If
                    Next

                End If

            Catch ex As Exception
                Call WriteError(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message)
            End Try

        End Sub

    End Class
End Class