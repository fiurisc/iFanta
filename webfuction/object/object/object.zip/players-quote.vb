﻿Imports System.Net
Imports System.IO
Imports System.Text

Partial Class WebData

    Function GetPlayersQuote(ServerPath As String, GetQuotes_Fantacalcio_it As Boolean, ReturnData As Boolean) As String

        If GetQuotes_Fantacalcio_it Then
            Return GetPlayersQuoteFantacalcio(ServerPath, ReturnData)
        Else
            Return GetPlayersQuotePianetaFantacalcio(ServerPath, ReturnData)
        End If
        'Dim strdata As New System.Text.StringBuilder

        'If GetQuotes_Fantacalcio_it Then
        '    strdata.AppendLine("Dati da pianeta fantacalcio")
        '    strdata.AppendLine(GetPlayersQuoteFantacalcio(ServerPath, ReturnData))
        '    strdata.AppendLine("-------------------------------------")
        'End If
        'strdata.AppendLine(GetPlayersQuotePianetaFantacalcio(ServerPath, GetQuotes_Fantacalcio_it, ReturnData))
        'Return strdata.ToString
    End Function

    Function GetPlayersQuotePianetaFantacalcio(ServerPath As String, ReturnData As Boolean) As String

        Dim dirt As String = ServerPath & "\web\" & CStr(year) & "\temp"
        Dim dird As String = ServerPath & "\web\" & CStr(year) & "\data"
        Dim filet As String = dirt & "\players-quote.txt"
        Dim filed As String = dird & "\players-quote.txt"
        Dim strdata As New System.Text.StringBuilder

        dirs = ServerPath

        Try

            Dim html As String = GetPage("https://www.pianetafanta.it/Giocatori-Quotazioni.asp?giornata=&Nome=&Quota=&Quota1=&Squadre21=T&Cerca=Cerca", "POST", "")

            If IO.Directory.Exists(dirt) = False Then IO.Directory.CreateDirectory(dirt)
            If IO.Directory.Exists(dird) = False Then IO.Directory.CreateDirectory(dird)

            If html <> "" Then

                IO.File.WriteAllText(filet, html)

                Dim line() As String = IO.File.ReadAllLines(filet, System.Text.Encoding.GetEncoding("ISO-8859-1"))
                Dim nome As String = ""
                Dim squadra As String = ""
                Dim qini As String = ""
                Dim qcur As String = ""
                Dim ruolo As String = ""
                Dim strtmp As New StringBuilder
                Dim start As Boolean = False

                For i As Integer = 0 To line.Length - 1

                    If line(i).Contains("<tr class=""generico"">") Then
                        start = True
                    End If

                    If start AndAlso line(i) <> "" Then strtmp.AppendLine(line(i))

                    If line(i).Contains("</tr>") Then
                        If start Then
                            Dim s() As String = strtmp.ToString.Split(CChar(System.Environment.NewLine))
                            For k As Integer = 0 To s.Length - 1
                                If s(k).Contains("images/transparent.gif"" class=""SpriteSquadre ") Then squadra = System.Text.RegularExpressions.Regex.Match(s(k), "(?<=title="")[a-zA-Z]{1,}(?="")").Value.ToUpper
                                If s(k).ToLower.Contains("giocatori-statistiche-personali.asp?nomegio=") Then
                                    s(k) = s(k).Replace("&#8217;", "’")
                                    nome = System.Text.RegularExpressions.Regex.Match(s(k), "(?<=nomegio\=).*(?=\&Ruolo)").Value.ToUpper.Trim
                                    'If nome.EndsWith(".") = False Then nome = nome & "."
                                    ruolo = System.Text.RegularExpressions.Regex.Match(s(k).ToLower, "(?<=ruolo=)[pdca]").Value.ToUpper
                                    If nome.Contains("DOUGLAS COSTA") Then
                                        nome = nome
                                    End If
                                    nome = NormalizeText(nome)
                                End If
                                If System.Text.RegularExpressions.Regex.Match(s(k), "<td style="" width:25px;text-align:center""><b>").Value.Length > 0 Then
                                    qini = System.Text.RegularExpressions.Regex.Match(s(k + 1), "\d+").Value
                                End If
                                If System.Text.RegularExpressions.Regex.Match(s(k), "<font face=""Verdana"" size=""3""><strong>").Value.Length > 0 Then
                                    qcur = System.Text.RegularExpressions.Regex.Match(s(k + 1), "\d+").Value
                                    strdata.AppendLine(ruolo & "|" & nome & "|" & squadra & "|" & qini & "|" & qcur)
                                End If
                            Next
                        End If
                        start = False
                        strtmp = New StringBuilder
                    End If
                Next

                IO.File.WriteAllText(filed, strdata.ToString, Encoding.UTF8)

                webplayers.Clear()

                Call LoadWebPlayers(filed)

            End If

            If ReturnData Then
                Return "</br><span style=color:red;font-size:bold;'>Players quotes (" & year & "):</span></br>" & strdata.ToString.Replace(System.Environment.NewLine, "</br>") & "</br>"
            Else
                Return ("</br><span style=color:red;font-size:bold;'>Players quotes (" & year & "):</span><span style=color:blue;font-size:bold;'>Compleated!!</span></br>")
            End If

        Catch ex As Exception
            Call WriteError(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message)
            Return ex.Message
        End Try

    End Function

    Function GetPlayersQuoteFantacalcio(ServerPath As String, ReturnData As Boolean) As String

        Dim dirt As String = ServerPath & "\web\" & CStr(year) & "\temp"
        Dim dird As String = ServerPath & "\web\" & CStr(year) & "\data"
        Dim filet As String = dirt & "\players-quote.zip"
        Dim filed As String = dird & "\players-quote.txt"
        Dim strdata As New System.Text.StringBuilder

        dirs = ServerPath

        Try

            Using webClient As WebClient = New WebClient()
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12
                webClient.DownloadFile("https://www.fantacalcio.it//Servizi/Excel.ashx?type=0&r=1&t=1599679396000", filet)
            End Using
            If IO.Directory.Exists(dirt) = False Then IO.Directory.CreateDirectory(dirt)
            If IO.Directory.Exists(dird) = False Then IO.Directory.CreateDirectory(dird)
            If IO.Directory.Exists(dirt + "\unzippq") = False Then IO.Directory.CreateDirectory(dirt + "\unzippq")
            IO.Directory.Delete(dirt + "\unzippq", True)
            System.IO.Compression.ZipFile.ExtractToDirectory(filet, dirt + "\unzippq")

            Dim fsheet1 As String = dirt + "\unzippq\xl\worksheets\sheet1.xml"
            Dim fsheet2 As String = dirt + "\unzippq\xl\worksheets\sheet1.txt"
            Dim fstr1 As String = dirt + "\unzippq\xl\sharedStrings.xml"
            Dim fstr2 As String = dirt + "\unzippq\xl\sharedStrings.xml"

            If IO.File.Exists(fsheet1) AndAlso IO.File.Exists(fstr1) Then

                Dim sharedstr As Generic.List(Of String) = GetDictionaryString(fstr1, fstr2)

                Dim str As String = System.Text.RegularExpressions.Regex.Match(IO.File.ReadAllText(fsheet1), "\<row.*\<\/row\>").Value
                IO.File.WriteAllText(fsheet2, "<rows>" & str & "</rows>")

                Dim m_xmld As System.Xml.XmlDocument
                Dim m_nodelist As System.Xml.XmlNodeList
                Dim m_node As System.Xml.XmlNode

                m_xmld = New System.Xml.XmlDocument()
                m_xmld.Load(fsheet2)

                m_nodelist = m_xmld.SelectNodes("/rows/row")

                For Each m_node In m_nodelist

                    Dim cellval As New StringBuilder

                    For Each nodemeas As System.Xml.XmlNode In m_node.ChildNodes

                        Dim cell As String = nodemeas.Attributes("r").Value
                        Dim col As String = System.Text.RegularExpressions.Regex.Match(cell, "[A-Z]").Value
                        Dim row As Integer = CInt(System.Text.RegularExpressions.Regex.Match(cell, "\d+").Value)

                        If row > 2 AndAlso "BCDEF".Contains(col) Then
                            Dim val As String = ""
                            If nodemeas.Attributes("t") IsNot Nothing Then
                                Dim sind As Integer = CInt(nodemeas.InnerText)
                                val = sharedstr(sind)
                            Else
                                val = nodemeas.InnerText
                            End If
                            Select Case col
                                Case "B" : val = val.ToUpper()
                                Case "C" : val = NormalizeText(val.ToUpper().Replace("-", " "))
                                Case "D" : val = CheckTeamName(NormalizeText(val.ToUpper()))
                            End Select
                            cellval.Append("|" & val)
                        End If

                    Next
                    If cellval.Length > 0 Then strdata.AppendLine(cellval.ToString().Substring(1))
                Next
            End If

            IO.File.WriteAllText(filed, strdata.ToString, Encoding.UTF8)

            webplayers.Clear()

            Call LoadWebPlayers(filed)

            If ReturnData Then
                Return "</br><span style=color:red;font-size:bold;'>Players quotes (" & year & "):</span></br>" & strdata.ToString.Replace(System.Environment.NewLine, "</br>") & "</br>"
            Else
                Return ("</br><span style=color:red;font-size:bold;'>Players quotes (" & year & "):</span><span style=color:blue;font-size:bold;'>Compleated!!</span></br>")
            End If

        Catch ex As Exception
            Call WriteError(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message)
            Return ex.Message
        End Try

    End Function

    Function GetPlayersQuotePianetaFantacalcio(ServerPath As String, Match_Quotes_Fantacalcio_it As Boolean, ReturnData As Boolean) As String

        Dim dirt As String = ServerPath & "\web\" & CStr(year) & "\temp"
        Dim dird As String = ServerPath & "\web\" & CStr(year) & "\data"
        Dim filet As String = dirt & "\players-quote.txt"
        Dim filed As String = dird & "\players-quote.txt"
        Dim strdata As New System.Text.StringBuilder

        dirs = ServerPath

        Try

            Dim html As String = GetPage("https://www.pianetafanta.it/Giocatori-Quotazioni.asp?giornata=&Nome=&Quota=&Quota1=&Squadre21=T&Cerca=Cerca", "POST", "")

            If IO.Directory.Exists(dirt) = False Then IO.Directory.CreateDirectory(dirt)
            If IO.Directory.Exists(dird) = False Then IO.Directory.CreateDirectory(dird)

            If html <> "" Then

                IO.File.WriteAllText(filet, html)

                Dim line() As String = IO.File.ReadAllLines(filet, System.Text.Encoding.GetEncoding("ISO-8859-1"))
                Dim nome As String = ""
                Dim squadra As String = ""
                Dim qini As String = ""
                Dim qcur As String = ""
                Dim ruolo As String = ""
                Dim strtmp As New StringBuilder
                Dim start As Boolean = False

                For i As Integer = 0 To line.Length - 1

                    If line(i).Contains("<tr class=""generico"">") Then
                        start = True
                    End If

                    If start AndAlso line(i) <> "" Then strtmp.AppendLine(line(i))

                    If line(i).Contains("</tr>") Then
                        If start Then
                            Dim s() As String = strtmp.ToString.Split(CChar(System.Environment.NewLine))
                            For k As Integer = 0 To s.Length - 1
                                If s(k).Contains("images/transparent.gif"" class=""SpriteSquadre ") Then squadra = System.Text.RegularExpressions.Regex.Match(s(k), "(?<=title="")[a-zA-Z]{1,}(?="")").Value.ToUpper
                                If s(k).ToLower.Contains("giocatori-statistiche-personali.asp?nomegio=") Then
                                    s(k) = s(k).Replace("&#8217;", "’")
                                    nome = System.Text.RegularExpressions.Regex.Match(s(k), "(?<=nomegio\=).*(?=\&Ruolo)").Value.ToUpper.Trim
                                    'If nome.EndsWith(".") = False Then nome = nome & "."
                                    ruolo = System.Text.RegularExpressions.Regex.Match(s(k).ToLower, "(?<=ruolo=)[pdca]").Value.ToUpper
                                    If nome.Contains("DOUGLAS COSTA") Then
                                        nome = nome
                                    End If
                                    nome = NormalizeText(nome)
                                End If
                                If System.Text.RegularExpressions.Regex.Match(s(k), "<td style="" width:25px;text-align:center""><b>").Value.Length > 0 Then
                                    qini = System.Text.RegularExpressions.Regex.Match(s(k + 1), "\d+").Value
                                End If
                                If System.Text.RegularExpressions.Regex.Match(s(k), "<font face=""Verdana"" size=""3""><strong>").Value.Length > 0 Then
                                    qcur = System.Text.RegularExpressions.Regex.Match(s(k + 1), "\d+").Value
                                    strdata.AppendLine(ruolo & "|" & nome & "|" & squadra & "|" & qini & "|" & qcur)
                                End If
                            Next
                        End If
                        start = False
                        strtmp = New StringBuilder
                    End If
                Next

                IO.File.WriteAllText(filed, strdata.ToString, Encoding.UTF8)

                webplayers.Clear()

                Call LoadWebPlayers(filed)

                If Match_Quotes_Fantacalcio_it Then

                    filet = dirt & "\players-quote-fantacalcio_it.txt"

                    strdata = New StringBuilder

                    If IO.File.Exists(filet) Then

                        line = IO.File.ReadAllLines(filet)

                        For Each str As String In line

                            Dim s() As String = str.Split(CChar("|"))

                            If s.Length = 7 Then

                                Dim pm As WebData.PlayerMatch = WebData.CheckName(s(1), s(2), s(3))
                                If pm.Matched = False Then pm = WebData.CheckName("", s(2), s(3))

                                If pm.Matched Then
                                    strdata.AppendLine(pm.MatchedPlayer.Role & "|" & pm.MatchedPlayer.Name & "|" & pm.MatchedPlayer.Team & "|" & s(4) & "|" & s(5))
                                End If
                            End If
                        Next

                    Else
                        webplayers.Clear()
                        If IO.File.Exists(filed) Then IO.File.Delete(filed)
                    End If

                End If
            End If

            If ReturnData Then
                Return "</br><span style=color:red;font-size:bold;'>Players quotes (" & year & "):</span></br>" & strdata.ToString.Replace(System.Environment.NewLine, "</br>") & "</br>"
            Else
                Return ("</br><span style=color:red;font-size:bold;'>Players quotes (" & year & "):</span><span style=color:blue;font-size:bold;'>Compleated!!</span></br>")
            End If

        Catch ex As Exception
            Call WriteError(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message)
            Return ex.Message
        End Try

    End Function

    Function GetPlayersQuoteFantacalcioOther(ServerPath As String, ReturnData As Boolean) As String

        Dim dirt As String = ServerPath & "\web\" & CStr(year) & "\temp"
        Dim filet As String = dirt & "\players-quote.zip"
        Dim filed As String = dirt & "\players-quote-fantacalcio_it.txt"
        Dim strdata As New System.Text.StringBuilder

        dirs = ServerPath

        Try

            'Using webClient As WebClient = New WebClient()
            '    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12
            '    webClient.DownloadFile("https://www.fantacalcio.it//Servizi/Excel.ashx?type=0&r=1&t=1598268206000", filet)
            'End Using
            'IO.Directory.Delete(dirt + "\unzippq", True)
            'System.IO.Compression.ZipFile.ExtractToDirectory(filet, dirt + "\unzippq")

            Dim fsheet1 As String = dirt + "\unzippq\xl\worksheets\sheet1.xml"
            Dim fsheet2 As String = dirt + "\unzippq\xl\worksheets\sheet1.txt"
            Dim fstr1 As String = dirt + "\unzippq\xl\sharedStrings.xml"
            Dim fstr2 As String = dirt + "\unzippq\xl\sharedStrings.xml"

            If IO.File.Exists(fsheet1) AndAlso IO.File.Exists(fstr1) Then

                Dim sharedstr As Generic.List(Of String) = GetDictionaryString(fstr1, fstr2)

                Dim str As String = System.Text.RegularExpressions.Regex.Match(IO.File.ReadAllText(fsheet1), "\<row.*\<\/row\>").Value
                IO.File.WriteAllText(fsheet2, "<rows>" & str & "</rows>")

                Dim m_xmld As System.Xml.XmlDocument
                Dim m_nodelist As System.Xml.XmlNodeList
                Dim m_node As System.Xml.XmlNode

                m_xmld = New System.Xml.XmlDocument()
                m_xmld.Load(fsheet2)

                m_nodelist = m_xmld.SelectNodes("/rows/row")

                For Each m_node In m_nodelist

                    Dim cellval As New StringBuilder

                    For Each nodemeas As System.Xml.XmlNode In m_node.ChildNodes

                        Dim cell As String = nodemeas.Attributes("r").Value
                        Dim col As String = System.Text.RegularExpressions.Regex.Match(cell, "[A-Z]").Value
                        Dim row As Integer = CInt(System.Text.RegularExpressions.Regex.Match(cell, "\d+").Value)

                        If row > 2 Then
                            Dim val As String = ""
                            If nodemeas.Attributes("t") IsNot Nothing Then
                                Dim sind As Integer = CInt(nodemeas.InnerText)
                                val = sharedstr(sind)
                            Else
                                val = nodemeas.InnerText
                            End If
                            Select Case col
                                Case "B" : val = val.ToUpper()
                                Case "C" : val = NormalizeText(val.ToUpper())
                                Case "D" : val = CheckTeamName(NormalizeText(val.ToUpper()))
                            End Select
                            cellval.Append("|" & val)
                        End If

                    Next
                    If cellval.Length > 0 Then strdata.AppendLine(cellval.ToString().Substring(1))

                    m_node = m_node
                Next
            End If

            'Dim fs As FileStream = New FileStream("quotes.zip", FileMode.Open)
            'Dim fsOutput As FileStream = New FileStream(savePath1, FileMode.Create, FileAccess.Write)
            'Dim zip As GZipStream = New System.IO.Compression.GZipStream(fs, CompressionMode.Decompress, True)

            'Dim buffer(4096) As Byte
            'Dim bytesRead As Integer
            'Dim continueLoop As Boolean = True

            'While (continueLoop)
            '    bytesRead = zip.Read(buffer, 0, buffer.Length)
            '    If bytesRead = 0 Then
            '        Exit While
            '    End If
            '    fsOutput.Write(buffer, 0, bytesRead)
            'End While

            'zip.Close()
            'fsOutput.Close()
            'fs.Close()


            'If IO.Directory.Exists(dirt) = False Then IO.Directory.CreateDirectory(dirt)
            'If IO.Directory.Exists(dird) = False Then IO.Directory.CreateDirectory(dird)

            'If html <> "" Then

            '    IO.File.WriteAllText(filet, html)

            '    Dim line() As String = IO.File.ReadAllLines(filet, System.Text.Encoding.GetEncoding("ISO-8859-1"))
            '    Dim nome As String = ""
            '    Dim squadra As String = ""
            '    Dim qini As String = ""
            '    Dim qcur As String = ""
            '    Dim ruolo As String = ""
            '    Dim strtmp As New StringBuilder
            '    Dim start As Boolean = False

            '    For i As Integer = 0 To line.Length - 1

            '        If line(i).Contains("<tr class=""generico"">") Then
            '            start = True
            '        End If

            '        If start AndAlso line(i) <> "" Then strtmp.AppendLine(line(i))

            '        If line(i).Contains("</tr>") Then
            '            If start Then
            '                Dim s() As String = strtmp.ToString.Split(CChar(System.Environment.NewLine))
            '                For k As Integer = 0 To s.Length - 1
            '                    If s(k).Contains("images/transparent.gif"" class=""SpriteSquadre ") Then squadra = System.Text.RegularExpressions.Regex.Match(s(k), "(?<=title="")[a-zA-Z]{1,}(?="")").Value.ToUpper
            '                    If s(k).ToLower.Contains("giocatori-statistiche-personali.asp?nomegio=") Then
            '                        s(k) = s(k).Replace("&#8217;", "’")
            '                        nome = System.Text.RegularExpressions.Regex.Match(s(k), "(?<=nomegio\=).*(?=\&Ruolo)").Value.ToUpper.Trim
            '                        'If nome.EndsWith(".") = False Then nome = nome & "."
            '                        ruolo = System.Text.RegularExpressions.Regex.Match(s(k).ToLower, "(?<=ruolo=)[pdca]").Value.ToUpper
            '                        If nome.Contains("DOUGLAS COSTA") Then
            '                            nome = nome
            '                        End If
            '                        nome = NormalizeText(nome)
            '                    End If
            '                    If System.Text.RegularExpressions.Regex.Match(s(k), "<td style="" width:25px;text-align:center""><b>").Value.Length > 0 Then
            '                        qini = System.Text.RegularExpressions.Regex.Match(s(k + 1), "\d+").Value
            '                    End If
            '                    If System.Text.RegularExpressions.Regex.Match(s(k), "<font face=""Verdana"" size=""3""><strong>").Value.Length > 0 Then
            '                        qcur = System.Text.RegularExpressions.Regex.Match(s(k + 1), "\d+").Value
            '                        strdata.AppendLine(ruolo & "|" & nome & "|" & squadra & "|" & qini & "|" & qcur)
            '                    End If
            '                Next
            '            End If
            '            start = False
            '            strtmp = New StringBuilder
            '        End If
            '    Next

            IO.File.WriteAllText(filed, strdata.ToString, Encoding.UTF8)

            '    webplayers.Clear()

            '    Call LoadWebPlayers(filed)

            'End If

            If ReturnData Then
                Return "</br><span style=color:red;font-size:bold;'>Players quotes (" & year & "):</span></br>" & strdata.ToString.Replace(System.Environment.NewLine, "</br>") & "</br>"
            Else
                Return ("</br><span style=color:red;font-size:bold;'>Players quotes (" & year & "):</span><span style=color:blue;font-size:bold;'>Compleated!!</span></br>")
            End If

        Catch ex As Exception
            Call WriteError(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message)
            Return ex.Message
        End Try

    End Function

    Public Function GetDictionaryString(f1 As String, f2 As String) As Generic.List(Of String)

        Dim lst As New Generic.List(Of String)

        Try
            Dim str As String = System.Text.RegularExpressions.Regex.Match(IO.File.ReadAllText(f1), "\<si.*\<\/si\>").Value
            IO.File.WriteAllText(f2, "<str>" & str & "</str>")

            Dim m_xmld As System.Xml.XmlDocument
            Dim m_nodelist As System.Xml.XmlNodeList
            Dim m_node As System.Xml.XmlNode

            m_xmld = New System.Xml.XmlDocument()
            m_xmld.Load(f2)

            m_nodelist = m_xmld.SelectNodes("/str/si")

            For Each m_node In m_nodelist
                lst.Add(m_node.InnerText)
            Next
        Catch ex As Exception
            Call WriteError(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message)
        End Try

        Return lst

    End Function
End Class
