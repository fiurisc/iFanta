﻿Imports System.Net
Imports System.IO
Imports System.Text

Partial Class WebData

    Private year As Integer = -1

    Sub New(YearLega As Integer)
        year = YearLega
    End Sub

    Function GetPlayersData(ServerPath As String, ReturnData As Boolean) As String

        Dim dirt As String = ServerPath & "\web\" & CStr(year) & "\temp"
        Dim dird As String = ServerPath & "\web\" & CStr(year) & "\data"
        Dim filed As String = dird & "\players-data.txt"
        Dim filep As String = dird & "\players-data-player.txt"
        Dim strdata As New System.Text.StringBuilder
        Dim strnameerr As New System.Text.StringBuilder
        Dim strplayer As New System.Text.StringBuilder

        dirs = ServerPath

        Try

            Call LoadWebPlayers(ServerPath & "\web\" & CStr(year) & "\data\players-quote.txt")

            Dim dicnatcode As Dictionary(Of String, String) = GetDicNatCodeList(ServerPath & "\web\code.txt")
            Dim sqlink As New Dictionary(Of String, String)
            Dim team As Generic.List(Of String) = GetTeamList(ServerPath)
            Dim plist As New Generic.List(Of String)
            Dim wpl As New Dictionary(Of String, WebData.PlayerMatch)

            For i As Integer = 0 To team.Count - 1
                sqlink.Add(team(i), "http://www.legaseriea.it/it/serie-a/squadre/" & team(i) & "/squadra/" & year & "-" & CStr(year - 1999))
            Next

            For Each sq As String In sqlink.Keys

                Dim html As String = GetPage(sqlink(sq), "POST", "")

                If IO.Directory.Exists(dirt) = False Then IO.Directory.CreateDirectory(dirt)
                If IO.Directory.Exists(dird) = False Then IO.Directory.CreateDirectory(dird)

                sq = CheckTeamName(sq)

                If html <> "" Then

                    Dim filet As String = dirt & "\players-data-" & sq.ToLower & ".txt"

                    IO.File.WriteAllText(filet, html, System.Text.Encoding.GetEncoding("ISO-8859-1"))

                    Dim role As String = ""
                    Dim line() As String = IO.File.ReadAllLines(filet)
                    Dim dicname As New Generic.List(Of String)

                    For i As Integer = 0 To line.Length - 1

                        If line(i).ToLower.Contains("trasferiti") Then
                            Exit For
                        End If

                        If line(i).Contains("<a href=""/it/giocatori/") Then

                            If line(i + 5).ToLower.Contains("portiere") Then
                                role = "P"
                            ElseIf line(i + 5).ToLower.Contains("difensore") Then
                                role = "D"
                            ElseIf line(i + 5).ToLower.Contains("centrocampista") Then
                                role = "C"
                            ElseIf line(i + 5).ToLower.Contains("attaccante") Then
                                role = "A"
                            Else
                                role = ""
                            End If

                            If role <> "" Then

                                Dim nome As String = System.Text.RegularExpressions.Regex.Match(line(i + 1), "(?<=span>).*(?=\</span)").Value.ToUpper.Replace("-", " ").Trim
                                Dim nat As String = ""
                                Dim natcode As String = GetNatCode(System.Text.RegularExpressions.Regex.Match(line(i + 7), "(?<=alt\=\"")\w+(?=\"")").Value.ToUpper)

                                If dicnatcode.ContainsKey(natcode) Then nat = dicnatcode(natcode) Else nat = "?"

                                If nome <> "" AndAlso dicname.Contains(nome) = False Then

                                    If nome.Contains("VERDI") Then
                                        nome = nome
                                    End If

                                    dicname.Add(nome)

                                    nome = NormalizeText(nome.Replace("'", ""))

                                    If wpl.ContainsKey(nome) = False Then

                                        Dim pm As WebData.PlayerMatch = WebData.CheckName(role, nome, sq)
                                        If pm.Matched = False Then pm = WebData.CheckName("", nome, sq)
                                        wpl.Add(nome, pm)
                                        strdata.AppendLine(role & "|" & pm.GetName & "|" & sq & "|" & nat & "|" & natcode)

                                    End If
                                End If
                            End If

                        End If

                    Next
                End If

            Next

            IO.File.WriteAllText(filed, strdata.ToString, Encoding.UTF8)
            If makefileplayer Then Call WriteDataPlayerMatch(wpl, filep)
    
            If ReturnData Then
                Return "</br><span style=color:red;font-size:bold;'>Players data (" & year & "):</span></br>" & strdata.ToString.Replace(System.Environment.NewLine, "</br>") & "</br><span style='color:red;'>Name resolution error:</br>" & strnameerr.ToString.Replace(System.Environment.NewLine, "</br>") & "</span>"
            Else
                Return ("</br><span style=color:red;font-size:bold;'>Players data (" & year & "):</span><span style=color:blue;font-size:bold;'>Compleated!!</span></br>")
            End If

        Catch ex As Exception
            Call WriteError(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message)
            Return ex.Message
        End Try

    End Function

    Function GetTeamList(ServerPath As String) As Generic.List(Of String)

        Dim list As New Generic.List(Of String)

        Try

            Dim dirt As String = ServerPath & "\web\" & CStr(year) & "\temp"
            Dim dird As String = ServerPath & "\web\" & CStr(year) & "\data"
            Dim flgg As String = dirt & "\match-data-list-gg.txt"
            Dim html As String = GetPage("http://www.legaseriea.it/it/serie-a/classifica/" & year & "-" & CStr(year - 1999) & "", "POST", "")

            If html <> "" Then

                IO.File.WriteAllText(flgg, html)

                Dim line() As String = IO.File.ReadAllLines(flgg)

                For i As Integer = 0 To line.Length - 1
                    If line(i).Contains("/uploads/default/attachments/squadre") AndAlso line(i).Contains("</td>") Then
                        Dim team As String = System.Text.RegularExpressions.Regex.Match(line(i), "(?<=title\=\"")[A-Z\-\s]{0,}").Value.Replace(" ", "-")
                        If list.Contains(team) = False Then list.Add(team)
                    End If
                Next
            End If

        Catch ex As Exception
            Call WriteError(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message)
        End Try

        Return list

    End Function
End Class
